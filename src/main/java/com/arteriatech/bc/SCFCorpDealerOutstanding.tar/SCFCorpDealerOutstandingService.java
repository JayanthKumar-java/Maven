/**
 * SCFCorpDealerOutstandingService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.arteriatech.bc.SCFCorpDealerOutstanding;

public interface SCFCorpDealerOutstandingService extends javax.xml.rpc.Service {
    public java.lang.String getSCFCorpDealerOutstandingPortAddress();

    public com.arteriatech.bc.SCFCorpDealerOutstanding.SCFCorpDealerOutstanding getSCFCorpDealerOutstandingPort() throws javax.xml.rpc.ServiceException;

    public com.arteriatech.bc.SCFCorpDealerOutstanding.SCFCorpDealerOutstanding getSCFCorpDealerOutstandingPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
