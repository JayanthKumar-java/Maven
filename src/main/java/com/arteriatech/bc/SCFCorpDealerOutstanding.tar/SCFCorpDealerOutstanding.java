/**
 * SCFCorpDealerOutstanding.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.arteriatech.bc.SCFCorpDealerOutstanding;

public interface SCFCorpDealerOutstanding extends java.rmi.Remote {
    public com.arteriatech.bc.SCFCorpDealerOutstanding.SCFCorpDealerOutstanding_PortalResponse SCFCorpDealerOutstanding(com.arteriatech.bc.SCFCorpDealerOutstanding.SCFCorpDealerOutstanding_Request SCFCorpDealerOutstanding_Request) throws java.rmi.RemoteException;
}
